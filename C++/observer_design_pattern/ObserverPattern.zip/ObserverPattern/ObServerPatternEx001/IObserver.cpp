#include "IObserver.h"

IObserver::IObserver()
{

}
